import { BrowserRouter as Router, Routes, Route, NavLink } from 'react-router-dom';

import { Users, CheckSquare, BookOpen, MessageSquare, DollarSign, Home, Menu } from 'lucide-react';
import { useState } from 'react';

// Types
interface Student {
  id: string;
  name: string;
  studentId: string;
  course: string;
  grade: string;
}

interface Task {
  id: string;
  title: string;
  completed: boolean;
  dueDate: string;
}

interface Book {
  id: string;
  title: string;
  author: string;
  isbn: string;
  status: 'available' | 'issued';
  issuedTo?: string;
  issueDate?: string;
}

interface Feedback {
  id: string;
  name: string;
  email: string;
  rating: number;
  comment: string;
  date: string;
}

interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
}

// Student Management Component
function StudentManagement() {
  const [students, setStudents] = useState<Student[]>(() => {
    const saved = localStorage.getItem('students');
    return saved ? JSON.parse(saved) : [];
  });
  const [form, setForm] = useState({ name: '', studentId: '', course: '', grade: '' });
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState('');

  const saveToStorage = (data: Student[]) => {
    localStorage.setItem('students', JSON.stringify(data));
    setStudents(data);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.studentId || !form.course || !form.grade) return;

    if (editingId) {
      const updated = students.map(s => s.id === editingId ? { ...s, ...form } : s);
      saveToStorage(updated);
      setEditingId(null);
    } else {
      const newStudent: Student = { id: Date.now().toString(), ...form };
      saveToStorage([...students, newStudent]);
    }
    setForm({ name: '', studentId: '', course: '', grade: '' });
  };

  const editStudent = (student: Student) => {
    setForm({ name: student.name, studentId: student.studentId, course: student.course, grade: student.grade });
    setEditingId(student.id);
  };

  const deleteStudent = (id: string) => {
    const updated = students.filter(s => s.id !== id);
    saveToStorage(updated);
  };

  const filteredStudents = students.filter(s =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.studentId.toLowerCase().includes(search.toLowerCase()) ||
    s.course.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8 flex items-center gap-4">
        <img src="/images/student-hero.jpg" alt="Students" className="w-full h-48 object-cover rounded-2xl shadow-xl" />
      </div>
      <div className="bg-white rounded-3xl shadow-xl p-8">
        <h2 className="text-3xl font-semibold mb-6 flex items-center gap-3 text-slate-900">
          <Users className="w-8 h-8 text-blue-600" /> Student Management System
        </h2>

        <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-8">
          <input type="text" placeholder="Full Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" />
          <input type="text" placeholder="Student ID" value={form.studentId} onChange={e => setForm({ ...form, studentId: e.target.value })} className="border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" />
          <input type="text" placeholder="Course" value={form.course} onChange={e => setForm({ ...form, course: e.target.value })} className="border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" />
          <input type="text" placeholder="Grade" value={form.grade} onChange={e => setForm({ ...form, grade: e.target.value })} className="border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" />
          <button type="submit" className="bg-blue-600 hover:bg-blue-700 transition text-white rounded-xl px-6 py-3 font-medium">
            {editingId ? 'Update Student' : 'Add Student'}
          </button>
        </form>

        <div className="mb-4">
          <input type="text" placeholder="Search students..." value={search} onChange={e => setSearch(e.target.value)} className="w-full md:w-96 border border-slate-200 rounded-xl px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500" />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-slate-200 text-left text-sm text-slate-500">
                <th className="py-4 px-4 font-medium">Name</th>
                <th className="py-4 px-4 font-medium">Student ID</th>
                <th className="py-4 px-4 font-medium">Course</th>
                <th className="py-4 px-4 font-medium">Grade</th>
                <th className="py-4 px-4 font-medium text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredStudents.length === 0 && <tr><td colSpan={5} className="py-8 text-center text-slate-400">No students found</td></tr>}
              {filteredStudents.map(student => (
                <tr key={student.id} className="border-b border-slate-100 hover:bg-slate-50 transition">
                  <td className="py-4 px-4 font-medium">{student.name}</td>
                  <td className="py-4 px-4 text-slate-600">{student.studentId}</td>
                  <td className="py-4 px-4 text-slate-600">{student.course}</td>
                  <td className="py-4 px-4"><span className="px-3 py-1 bg-emerald-100 text-emerald-700 rounded-full text-sm font-medium">{student.grade}</span></td>
                  <td className="py-4 px-4 text-right space-x-2">
                    <button onClick={() => editStudent(student)} className="text-blue-600 hover:text-blue-800 px-3 py-1.5">Edit</button>
                    <button onClick={() => deleteStudent(student.id)} className="text-red-600 hover:text-red-800 px-3 py-1.5">Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-4 text-sm text-slate-500 text-center">{students.length} total students</p>
      </div>
    </div>
  );
}

// Todo List Component
function TodoApp() {
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem('tasks');
    return saved ? JSON.parse(saved) : [];
  });
  const [newTask, setNewTask] = useState('');
  const [filter, setFilter] = useState<'all' | 'active' | 'completed'>('all');

  const saveTasks = (updated: Task[]) => {
    localStorage.setItem('tasks', JSON.stringify(updated));
    setTasks(updated);
  };

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTask.trim()) return;
    const task: Task = { id: Date.now().toString(), title: newTask.trim(), completed: false, dueDate: new Date(Date.now() + 86400000 * 3).toISOString().split('T')[0] };
    saveTasks([...tasks, task]);
    setNewTask('');
  };

  const toggleComplete = (id: string) => {
    const updated = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
    saveTasks(updated);
  };

  const deleteTask = (id: string) => saveTasks(tasks.filter(t => t.id !== id));

  const filtered = tasks.filter(t => {
    if (filter === 'active') return !t.completed;
    if (filter === 'completed') return t.completed;
    return true;
  });

  return (
    <div className="max-w-3xl mx-auto">
      <div className="mb-8"><img src="/images/todo-hero.jpg" alt="Todo" className="w-full h-48 object-cover rounded-2xl shadow-xl" /></div>
      <div className="bg-white rounded-3xl shadow-xl p-8">
        <h2 className="text-3xl font-semibold mb-6 flex items-center gap-3"><CheckSquare className="w-8 h-8 text-emerald-600" /> To-Do List</h2>

        <form onSubmit={addTask} className="flex gap-3 mb-8">
          <input type="text" value={newTask} onChange={e => setNewTask(e.target.value)} placeholder="What needs to be done?" className="flex-1 border border-slate-200 rounded-2xl px-6 py-3.5 text-lg focus:outline-none focus:ring-2 focus:ring-emerald-500" />
          <button type="submit" className="bg-emerald-600 text-white px-8 rounded-2xl font-medium hover:bg-emerald-700 transition">Add Task</button>
        </form>

        <div className="flex gap-2 mb-6">
          {(['all', 'active', 'completed'] as const).map(f => (
            <button key={f} onClick={() => setFilter(f)} className={`px-5 py-2 rounded-full text-sm font-medium transition ${filter === f ? 'bg-emerald-600 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-600'}`}>{f.charAt(0).toUpperCase() + f.slice(1)}</button>
          ))}
        </div>

        <div className="space-y-2">
          {filtered.length === 0 && <div className="py-10 text-center text-slate-400">No tasks found</div>}
          {filtered.map(task => (
            <div key={task.id} className="flex items-center justify-between bg-slate-50 hover:bg-slate-100 px-6 py-4 rounded-2xl group">
              <div className="flex items-center gap-4">
                <button onClick={() => toggleComplete(task.id)} className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition ${task.completed ? 'bg-emerald-600 border-emerald-600' : 'border-slate-300'}`}>
                  {task.completed && <CheckSquare className="w-4 h-4 text-white" />}
                </button>
                <div>
                  <div className={`${task.completed ? 'line-through text-slate-400' : 'text-slate-900'} font-medium`}>{task.title}</div>
                  <div className="text-xs text-slate-500">Due: {task.dueDate}</div>
                </div>
              </div>
              <button onClick={() => deleteTask(task.id)} className="opacity-0 group-hover:opacity-100 text-red-500 hover:text-red-600 transition">Delete</button>
            </div>
          ))}
        </div>
        <div className="mt-6 text-sm text-center text-slate-500">{tasks.filter(t => !t.completed).length} remaining tasks</div>
      </div>
    </div>
  );
}

// Library Management
function LibraryManagement() {
  const [books, setBooks] = useState<Book[]>(() => {
    const saved = localStorage.getItem('books');
    return saved ? JSON.parse(saved) : [];
  });
  const [form, setForm] = useState({ title: '', author: '', isbn: '' });
  const [issueModal, setIssueModal] = useState<{ bookId: string } | null>(null);
  const [issueTo, setIssueTo] = useState('');

  const saveBooks = (data: Book[]) => { localStorage.setItem('books', JSON.stringify(data)); setBooks(data); };

  const addBook = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title || !form.author || !form.isbn) return;
    const book: Book = { id: Date.now().toString(), ...form, status: 'available' };
    saveBooks([...books, book]);
    setForm({ title: '', author: '', isbn: '' });
  };

  const issueBook = (id: string) => {
    if (!issueTo.trim()) return;
    const updated = books.map(b => b.id === id ? { ...b, status: 'issued' as const, issuedTo: issueTo.trim(), issueDate: new Date().toISOString().split('T')[0] } : b);
    saveBooks(updated);
    setIssueModal(null);
    setIssueTo('');
  };

  const returnBook = (id: string) => {
    const updated = books.map(b => b.id === id ? { ...b, status: 'available' as const, issuedTo: undefined, issueDate: undefined } : b);
    saveBooks(updated);
  };

  const deleteBook = (id: string) => saveBooks(books.filter(b => b.id !== id));

  return (
    <div className="max-w-6xl mx-auto">
      <div className="mb-8"><img src="/images/library-hero.jpg" alt="Library" className="w-full h-48 object-cover rounded-2xl shadow-xl" /></div>
      <div className="bg-white rounded-3xl shadow-xl p-8">
        <h2 className="text-3xl font-semibold mb-6 flex items-center gap-3"><BookOpen className="w-8 h-8 text-amber-600" /> Library Management</h2>

        <form onSubmit={addBook} className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <input placeholder="Book Title" value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} className="border border-slate-200 px-5 py-3 rounded-2xl" />
          <input placeholder="Author" value={form.author} onChange={e => setForm({ ...form, author: e.target.value })} className="border border-slate-200 px-5 py-3 rounded-2xl" />
          <input placeholder="ISBN" value={form.isbn} onChange={e => setForm({ ...form, isbn: e.target.value })} className="border border-slate-200 px-5 py-3 rounded-2xl" />
          <button className="bg-amber-600 hover:bg-amber-700 text-white font-medium rounded-2xl">Add Book</button>
        </form>

        <div className="grid md:grid-cols-2 gap-4">
          {books.length === 0 && <div className="col-span-2 py-8 text-center text-slate-400">No books in library yet</div>}
          {books.map(book => (
            <div key={book.id} className="border border-slate-200 rounded-2xl p-6 flex flex-col justify-between">
              <div>
                <div className="font-semibold text-xl">{book.title}</div>
                <div className="text-slate-600">{book.author} • ISBN: {book.isbn}</div>
              </div>
              <div className="mt-4 flex items-center justify-between">
                <div>
                  {book.status === 'available' ? <span className="text-emerald-600 font-medium text-sm px-3 py-1 bg-emerald-50 rounded-full">Available</span> : <span className="text-amber-600 font-medium text-sm">Issued to {book.issuedTo} ({book.issueDate})</span>}
                </div>
                <div className="flex gap-2">
                  {book.status === 'available' ? <button onClick={() => setIssueModal({ bookId: book.id })} className="text-sm px-4 py-1.5 bg-amber-600 text-white rounded-xl">Issue</button> : <button onClick={() => returnBook(book.id)} className="text-sm px-4 py-1.5 border rounded-xl">Return</button>}
                  <button onClick={() => deleteBook(book.id)} className="text-sm px-3 py-1.5 text-red-500">×</button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {issueModal && (
          <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50">
            <div className="bg-white rounded-3xl p-8 w-full max-w-sm">
              <h3 className="font-semibold text-xl mb-4">Issue Book</h3>
              <input placeholder="Student Name" value={issueTo} onChange={e => setIssueTo(e.target.value)} className="w-full border px-5 py-3 rounded-2xl mb-4" />
              <div className="flex gap-3">
                <button onClick={() => setIssueModal(null)} className="flex-1 py-3 rounded-2xl border">Cancel</button>
                <button onClick={() => issueBook(issueModal.bookId)} className="flex-1 py-3 bg-amber-600 text-white rounded-2xl">Confirm Issue</button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Feedback System
function FeedbackSystem() {
  const [feedbacks, setFeedbacks] = useState<Feedback[]>(() => {
    const saved = localStorage.getItem('feedbacks'); return saved ? JSON.parse(saved) : [];
  });
  const [form, setForm] = useState({ name: '', email: '', rating: 5, comment: '' });

  const saveFeedback = (data: Feedback[]) => { localStorage.setItem('feedbacks', JSON.stringify(data)); setFeedbacks(data); };

  const submitFeedback = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.comment) return;
    const fb: Feedback = { id: Date.now().toString(), ...form, date: new Date().toISOString().split('T')[0] };
    saveFeedback([fb, ...feedbacks]);
    setForm({ name: '', email: '', rating: 5, comment: '' });
  };

  const avgRating = feedbacks.length ? (feedbacks.reduce((sum, f) => sum + f.rating, 0) / feedbacks.length).toFixed(1) : '—';

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8"><img src="/images/feedback-hero.jpg" alt="Feedback" className="w-full h-48 object-cover rounded-2xl shadow-xl" /></div>
      <div className="bg-white rounded-3xl shadow-xl p-8 grid md:grid-cols-5 gap-8">
        <div className="md:col-span-2">
          <h2 className="text-3xl font-semibold mb-3 flex items-center gap-3"><MessageSquare className="text-violet-600" /> Feedback System</h2>
          <div className="text-6xl font-semibold text-violet-600 mt-4">{avgRating}</div>
          <div className="text-slate-500">Average Rating ({feedbacks.length} responses)</div>
        </div>

        <form onSubmit={submitFeedback} className="md:col-span-3 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <input placeholder="Your Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} className="border px-5 py-3 rounded-2xl" required />
            <input type="email" placeholder="Email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} className="border px-5 py-3 rounded-2xl" />
          </div>
          <div>
            <div className="text-sm mb-2 text-slate-500">Rating</div>
            <div className="flex gap-1 text-3xl">{[1,2,3,4,5].map(n => <button key={n} type="button" onClick={() => setForm({ ...form, rating: n })} className={form.rating >= n ? 'text-amber-400' : 'text-slate-300'}>★</button>)}</div>
          </div>
          <textarea placeholder="Share your feedback..." value={form.comment} onChange={e => setForm({ ...form, comment: e.target.value })} className="border px-5 py-4 w-full h-28 rounded-2xl resize-y" required />
          <button className="bg-violet-600 text-white w-full py-3.5 rounded-2xl font-medium">Submit Feedback</button>
        </form>
      </div>

      <div className="mt-8">
        <h3 className="font-semibold text-xl mb-4 px-2">Recent Responses</h3>
        <div className="space-y-4">
          {feedbacks.length === 0 && <div className="text-slate-400 text-center py-8">No feedback yet</div>}
          {feedbacks.map(fb => (
            <div key={fb.id} className="bg-white rounded-2xl px-7 py-6 shadow">
              <div className="flex justify-between items-start mb-3">
                <div><div className="font-semibold">{fb.name}</div><div className="text-sm text-slate-500">{fb.email} • {fb.date}</div></div>
                <div className="text-amber-500 text-xl">{'★'.repeat(fb.rating)}</div>
              </div>
              <p className="text-slate-600 leading-relaxed">{fb.comment}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Expense Tracker
function ExpenseTracker() {
  const [expenses, setExpenses] = useState<Expense[]>(() => {
    const saved = localStorage.getItem('expenses'); return saved ? JSON.parse(saved) : [];
  });
  const [form, setForm] = useState({ description: '', amount: '', category: 'Food', date: new Date().toISOString().split('T')[0] });

  const categories = ['Food', 'Transport', 'Rent', 'Utilities', 'Entertainment', 'Other'];

  const saveExpenses = (data: Expense[]) => { localStorage.setItem('expenses', JSON.stringify(data)); setExpenses(data); };

  const addExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.description || !form.amount) return;
    const exp: Expense = { id: Date.now().toString(), description: form.description, amount: parseFloat(form.amount), category: form.category, date: form.date };
    saveExpenses([exp, ...expenses]);
    setForm({ description: '', amount: '', category: 'Food', date: new Date().toISOString().split('T')[0] });
  };

  const deleteExpense = (id: string) => saveExpenses(expenses.filter(e => e.id !== id));

  const total = expenses.reduce((sum, e) => sum + e.amount, 0);
  const byCategory = categories.map(cat => ({ cat, total: expenses.filter(e => e.category === cat).reduce((s, e) => s + e.amount, 0) })).filter(c => c.total > 0);

  return (
    <div className="max-w-5xl mx-auto">
      <div className="mb-8"><img src="/images/expense-hero.jpg" alt="Expenses" className="w-full h-48 object-cover rounded-2xl shadow-xl" /></div>
      <div className="bg-white rounded-3xl shadow-xl p-8">
        <div className="flex justify-between items-end mb-8">
          <div><h2 className="text-3xl font-semibold flex items-center gap-3"><DollarSign className="text-emerald-600" /> Expense Tracker</h2></div>
          <div className="text-right"><div className="text-4xl font-semibold text-emerald-600">${total.toFixed(2)}</div><div className="text-sm text-slate-500">Total Spent</div></div>
        </div>

        <form onSubmit={addExpense} className="grid md:grid-cols-5 gap-4 mb-8">
          <input placeholder="Description" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} className="md:col-span-2 border px-5 py-3 rounded-2xl" />
          <input type="number" step="0.01" placeholder="Amount" value={form.amount} onChange={e => setForm({ ...form, amount: e.target.value })} className="border px-5 py-3 rounded-2xl" />
          <select value={form.category} onChange={e => setForm({ ...form, category: e.target.value })} className="border px-5 py-3 rounded-2xl bg-white">
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <button className="bg-emerald-600 text-white rounded-2xl font-medium">Add Expense</button>
        </form>

        <div className="grid md:grid-cols-5 gap-8">
          <div className="md:col-span-3">
            <h4 className="font-medium mb-4 px-1">Recent Expenses</h4>
            {expenses.length === 0 && <div className="text-center py-8 text-slate-400">No expenses recorded</div>}
            <div className="space-y-2">
              {expenses.slice(0, 8).map(exp => (
                <div key={exp.id} className="flex justify-between items-center bg-slate-50 px-6 py-4 rounded-2xl">
                  <div><div className="font-medium">{exp.description}</div><div className="text-xs text-slate-500">{exp.date} • {exp.category}</div></div>
                  <div className="flex items-center gap-4"><span className="font-semibold text-lg">${exp.amount.toFixed(2)}</span><button onClick={() => deleteExpense(exp.id)} className="text-red-400 hover:text-red-600">×</button></div>
                </div>
              ))}
            </div>
          </div>
          <div className="md:col-span-2">
            <h4 className="font-medium mb-4 px-1">Breakdown by Category</h4>
            {byCategory.length === 0 ? <div className="text-sm text-slate-400">Add expenses to see breakdown</div> : byCategory.map(({ cat, total: catTotal }) => (
              <div key={cat} className="flex justify-between py-3 border-b last:border-none"><span>{cat}</span><span className="font-medium">${catTotal.toFixed(2)}</span></div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// Main App
function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const navItems = [
    { path: '/', label: 'Home', icon: Home },
    { path: '/students', label: 'Students', icon: Users },
    { path: '/todo', label: 'To-Do', icon: CheckSquare },
    { path: '/library', label: 'Library', icon: BookOpen },
    { path: '/feedback', label: 'Feedback', icon: MessageSquare },
    { path: '/expenses', label: 'Expenses', icon: DollarSign },
  ];

  return (
    <Router>
      <div className="min-h-screen bg-slate-50 font-sans">
        <nav className="bg-white border-b sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-20">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-2xl flex items-center justify-center"><span className="text-white font-bold text-xl">A</span></div>
              <div><div className="font-semibold text-2xl tracking-tighter">AcademiaHub</div><div className="text-[10px] text-slate-500 -mt-1">Campus Tools Suite</div></div>
            </div>

            <div className="hidden md:flex items-center gap-2">
              {navItems.map(item => (
                <NavLink key={item.path} to={item.path} className={({ isActive }) => `flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-medium transition ${isActive ? 'bg-slate-900 text-white' : 'hover:bg-slate-100 text-slate-600'}`}>
                  <item.icon className="w-4 h-4" /> {item.label}
                </NavLink>
              ))}
            </div>

            <button onClick={() => setMobileOpen(!mobileOpen)} className="md:hidden p-2"><Menu className="w-6 h-6" /></button>
          </div>

          {/* Mobile Menu */}
          {mobileOpen && (
            <div className="md:hidden border-t px-6 py-4 bg-white">
              {navItems.map(item => (
                <NavLink key={item.path} to={item.path} onClick={() => setMobileOpen(false)} className="flex items-center gap-3 py-3 text-slate-700 border-b last:border-none">
                  <item.icon className="w-5 h-5" /> {item.label}
                </NavLink>
              ))}
            </div>
          )}
        </nav>

        <Routes>
          <Route path="/" element={
            <div className="max-w-7xl mx-auto px-6 pt-16 pb-24">
              <div className="text-center mb-14">
                <div className="inline-block px-4 py-1 bg-blue-100 text-blue-700 rounded-full text-xs tracking-[3px] mb-4 font-medium">5 POWERFUL TOOLS</div>
                <h1 className="text-7xl font-semibold tracking-tighter mb-4">Everything you need.<br />All in one place.</h1>
                <p className="text-xl max-w-md mx-auto text-slate-600">Professional web applications for students, faculty, and administrators.</p>
              </div>
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {navItems.slice(1).map((item, idx) => (
                  <NavLink key={idx} to={item.path} className="group block bg-white rounded-3xl overflow-hidden border hover:shadow-xl transition-all hover:-translate-y-0.5">
                    <div className="aspect-video bg-slate-100 relative"><div className="absolute inset-0 flex items-center justify-center"><item.icon className="w-14 h-14 text-slate-300 group-hover:text-slate-400 transition" /></div></div>
                    <div className="p-7"><div className="font-semibold text-2xl tracking-tight">{item.label}</div><div className="text-slate-500 mt-1.5">Fully functional application</div></div>
                  </NavLink>
                ))}
              </div>
            </div>
          } />
          <Route path="/students" element={<StudentManagement />} />
          <Route path="/todo" element={<TodoApp />} />
          <Route path="/library" element={<LibraryManagement />} />
          <Route path="/feedback" element={<FeedbackSystem />} />
          <Route path="/expenses" element={<ExpenseTracker />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;

